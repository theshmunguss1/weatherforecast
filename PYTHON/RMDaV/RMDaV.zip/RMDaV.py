import datetime, urllib.request, urllib.error, os, time, http.server, socketserver

def welcome_menu():
    welcome = ["      Recent Mesoanalysis Downloader and Viewer (RMDaV)",
               "-------------------------------------------------------------",
               "   Released by Kyle Gentry, Mar 2018 :: ksgwxfan.github.io",
               "-------------------------------------------------------------",
               "*** Be sure to read the readme file before usage",
               "*** Make sure the script is in its own folder before using",
               "*** Follow the on-screen instructions",
               "DISCLAIMER: The Author is NOT responsible for any adverse operation",
               "    of the program. Use at your own risk!",
               "-------------------------------------------------------------"]
    for each in welcome:
        print(each)
    input("*** If you agree to the terms in the readme file and are ready to download, press ENTER to continue...\n")

def sector_menu():      # FUNCTION ASKS USER TO INPUT DESIRED REGION FOR ARCHIVAL
    sector_num = 0      # while-loop initiator
    while(sector_num < 11 or sector_num > 20):
        try:
            sector_num = int(input("""
            Select the sector from which you want your archive to be based on:
            *** IF CONUS SECTOR IS SELECTED, DATES MUST BE MANUALLY ENTERED IN THE CODE ***
              #11 - Pacific NW        #16 - Midwest/Northeast
              #12 - Southwest         #17 - Midwest/Mid-Atlantic
              #13 - Northern Plains   #18 - Southeast
              #14 - Central Plains    #19 - CONUS
              #15 - Southern Plains   #20 - Midwest
          
            ENTER SELECTION NOW: """))
            if sector_num >= 11 and sector_num <= 20:
                print("\n" + "You have selected sector #" + str(sector_num))
                return sector_num
            else:
                print("\n" + "INVALID ENTRY...TRY AGAIN...")
        except ValueError: # Used to handle error-causing float and alpha entries
            print("\n" + "INVALID ENTRY...TRY AGAIN...")
            sector_num = 0 # Resets the entry so the while-loop will continue

def length_menu(rgn):      # ASKS USER TO SPECIFY LENGTH OF ARCHIVE
    length_num = 0      # while-loop initiator
    while(length_num < 1 or length_num > 78):
        try:
            length_num = int(input("""
            Indicate how far back you'd like to archive (between 1 and 78 hours)...

            HOW MANY HOURS WOULD YOU LIKE YOUR ARCHIVE TO BE?: """))
            if length_num >= 1 and length_num <= 78:
                print("\n" + "You have chosen a " + str(length_num) + " hour archive")
                return length_num
            else:
                print("\n" + "INVALID ENTRY...TRY AGAIN...")
        except ValueError:
            print("\n" + "INVALID ENTRY...TRY AGAIN...")
            length_num = 0  # Resets variable so whlie-loop runs again

def product_menu(rgn):     # FUNCTION ASKS USER IF THEY HAVE PREFERENCE FOR SEVERE OR WINTER WEATHER ANIMATIONS

    prod_url = []   # Will hold all of the url prefix extensions for the individual products
    descript = []   # Will hold all of the descriptions for the individual products
    valid = False   # While-loop controller
    dload = []     # Will hold the final selection's extensions to be returned
    dload_desc = []      # Will hold the final selection's descriptions for use

    print("* Select products (using their respective integers) from the list below, separated by commas")
    print("--------------------------------------------------------------------------------------------")
    with open("product_list.txt","r") as r:
        for each in r.readlines():
            line = each.strip("\n").split(",")  # Creates a temporary array, separating the product extension & descrip
            prod_url.append(line[0])    # URL/Extension
            descript.append(line[1])    # Descriptions
        for every in range(len(prod_url)):  # On-Screen Listing; If/Else statements to handle placement of headers
            if every == 0:
                print("\n" + "SURFACE")
            elif every == 18:
                print("\n" + "UPPER-AIR")
            elif every == 41:
                print("\n" + "THERMODYNAMICS")
            elif every == 60:
                print("\n" + "WIND-SHEAR")
            elif every == 77:
                print("\n" + "COMPOSITE INDICES")
            elif every == 97:
                print("\n" + "MULTI-PARAMETER FIELDS")
            elif every == 107:
                print("\n" + "HEAVY RAIN")
            elif every == 111:
                print("\n" + "WINTER WEATHER")
            elif every == 125:
                print("\n" + "FIRE WEATHER")
            elif every == 131:
                print("\n" + "CLASSIC PRODUCTS")
            elif every == 133:
                print("\n" + "BETA")
            print(str(every+1) + ". " + str(descript[every]))   # Prints each product description
    print("- - - - - - - - - - - - - - - - - - - - - - ")
    while valid == False:
        # Attempts to retrieve an input list from the user of the products they wisht to download
        try:
            retr = input("PLEASE INPUT ALL PRODUCTS THAT YOU DESIRE, SEPARATED BY COMMAS, THEN PRESS ENTER: ").split(",")
            for each in retr:
                if (int(each) < 1 or int(each) > 142) or (len(retr) == 0):    # IF INVALID SELECTION IS INPUT
                    valid = False   # Ensures repeat of the while loop
                    print("!!! ERROR! Invalid Selection! Try Again...\n")
                    del retr   # Deletes the selection entries of the user to start over
                    break   # This halts the for-loop; restarts the while-loop
                else:
                    valid = True   # If all of the entries are valid; breaks the while loop
        except ValueError:
            print("ERROR! INVALID ENTRY or EMPTY LIST! TRY AGAIN!\n")    # Handles error; should also handle type errors (letter entry)
    for each in retr:  # retr holds the initial integer picks. This changes them to the proper index references
        retr[retr.index(each)] = int(each)-1
    print("\nYou have selected to download the following: ")    # LISTS THE PRODUCTS THAT THE USER SELECTED
    for every in retr:
        print("*** " + descript[every])
    input(" PRESS ENTER WHEN READY TO DOWNLOAD SELECTED PRODUCTS ...")
    for allv in retr:   # APPEND EACH UNIQUE PRODUCT URL Prefix and description TO DESIRED DOWNLOAD ARRAYS
        dload.append(prod_url[allv])
        dload_desc.append(descript[allv])
    return dload, dload_desc    # RETURN THE PRODUCT LIST and DESCRIPTION LIST

def create_prep_files(rgn,model_time,length):   # Creates filenames, then creates blank files that append as the program runs
    model_end = model_time + datetime.timedelta(hours=length-1)   #for the suffix of filenames
    # Create string of the desired filenames; config and filenames used in operation of HAniS module
    config_filename = "config_s" + str(rgn) + "_" + model_time.strftime("%y") + model_time.strftime("%m") + model_time.strftime("%d") \
            + model_time.strftime("%H") + "Z-" + model_end.strftime("%y") + model_end.strftime("%m") \
            + model_end.strftime("%d") + model_end.strftime("%H") + "Z.txt"
    filelist_name = "filelist_s" + str(rgn) + "_" + model_time.strftime("%y") + model_time.strftime("%m") + model_time.strftime("%d") \
            + model_time.strftime("%H") + "Z-" + model_end.strftime("%y") + model_end.strftime("%m") \
            + model_end.strftime("%d") + model_end.strftime("%H") + "Z.txt"
    # Create blank versions of needed files; will be appended to
    with open(config_filename,"w") as create:
        create.write("")
    with open(filelist_name,"w") as create:
        create.write("")
    return config_filename, filelist_name      

def make_dir(p,rgn):
    for num in range(len(p)):   # Will repeat according to the number of products in the list
        # Directory-check idea source: https://goo.gl/vl90v1
        # Purpose: Error will result upon download if destination folder doesn't exist
        if not os.path.exists("s" + str(rgn) + "/" + p[num]):
            os.makedirs("s" + str(rgn) + "/" + p[num])    # Generates a sector/product directory if it doesn't exist

def sector_download(rgn,prod,st,ln):
    i = 0   # COUNTER
    while i < len(products):
        TM = st     # Set the active time (TM) to the start time (st); resets initial time for each prod
        # The following loop initiates the download of each needed file
        for each_hour in range(ln):     # Repeats according to the desired length of the archive
            if products[i] == "rgnlrad":    # Designates download of radar imagery
                radar_http, radar_file = write_radar_links(TM,rgn) # Creates http and filenames for radar img
                download(radar_http,radar_file)     # Executes download attempt
            elif products[i] == "warns":    # Designates download of warnings overlay
                warnings_url, warnings_fi = write_warnings_links(TM,rgn) # Creates http and filenames for radar img
                download(warnings_url,warnings_fi)     # Executes download attempt            
            else:   # if the product of interest is NOT radar
                http_link, file_name = write_target_links(products[i],TM,rgn)  # Creates http/filenames for all other imgs
                download(http_link,file_name)       # Executes download attempt
            TM = TM + datetime.timedelta(hours=1)     #Progresses time one hour for retrieval of next file
        i = i + 1   # To advance to the next product in the list        

def write_radar_links(modelrun,region):   # Creates filename and url structure variables for radar; RETURNS 2 VARS
    r_file = "s" + str(region) + "/" + "rgnlrad/rad_" + modelrun.strftime("%Y") + modelrun.strftime("%m") \
             + modelrun.strftime("%d") + "_" + modelrun.strftime("%H") + "00.gif"
    r_http = "http://www.spc.noaa.gov/exper/mesoanalysis/" + r_file
    return r_http,r_file

def write_warnings_links(modelrun,region):  # Create filename and url structure variables for warnings; return 2 vars
    warn_file = "s" + str(region) + "/" + "warns/warns_" + modelrun.strftime("%Y") + modelrun.strftime("%m") \
             + modelrun.strftime("%d") + "_" + modelrun.strftime("%H") + "00.gif"
    warn_http = "http://www.spc.noaa.gov/exper/mesoanalysis/" + warn_file
    return warn_http,warn_file

def write_target_links(product,modelrun,region):    # Makes file and http structure for NON-radar imgs; RETURNS 2 VARS
    filename = "s" + str(region) + "/" + product + "/" + product + "_" + modelrun.strftime("%y") + modelrun.strftime("%m") \
                + modelrun.strftime("%d") + modelrun.strftime("%H") + ".gif"
    http = "http://www.spc.noaa.gov/exper/mesoanalysis/" + filename
    return http,filename

def download(http,file):    # Attempts to download requested file...SOURCE: https://goo.gl/OdivQl
    # http -> url link .... file -> folder/file name/download location
    try:        
        urllib.request.urlretrieve(http,file)   # Initiates the Download
        print("Download of: " + file + " is complete.")
    except urllib.error.HTTPError:      # If the file is not found or hasn't been generated yet
        print("File \"" + file + "\" not found on server!")

def config_write(rgn,config_name,filelist_name,meso_products,meso_desc):     # Creates the HAniS Config file
    with open(config_name,"a") as hanis_config:    # Opens the config file for appension
        hanis_config.write("start_looping = false" + "\n" \
                           + "file_of_filenames = " + filelist_name + "\n\n" \
                           + "controls = startstop, speed, backward, forward, framelabel, distance, annotate, overlay" + "\n" \
                           + "controls_tooltip = Start/Stop Animation, Speed Up/Slow Down Animation, Go BACK one frame," \
                               + "Go FORWARD one frame, Date/Time, Distance Tool, Draw, Overlay Multiple variables" + "\n" \
                           + "controls_style = display:flex;flex-flow:row;" \
                               + "background-color:white;border-radius:12px;" + "\n\n" \
                           + "buttons_style = background:linear-gradient(black,lightsteelblue);flex:auto;" \
                               + "margin:2px;color:white;background-color:black;text-transform:uppercase;" \
                               + "font-weight:bold;font-size:20;text-shadow:1px 1px 2px #000000;border-radius:12px;")
        hanis_config.write("\n\n" + "overlay_labels = ")
        for each in range(len(meso_products)):      # Comma-separates each product in list
            if each < (len(meso_products)-1):   # This if/else statement is to prevent comma after final product
                hanis_config.write(meso_products[each] + ",")
            else:
                hanis_config.write(meso_products[each])
        hanis_config.write("\n" + "overlay_tooltip = ")
        for each in range(len(meso_desc)):          # Comma-separates each product-description in list
            if each < (len(meso_desc)-1):       # This if/else statement is to prevent comma after final product desc
                hanis_config.write(meso_desc[each] + ", ")
            else:
                hanis_config.write(meso_desc[each])
        if rgn == 19:   # If it is the CONUS sector
            hanis_config.write("\n" + "distance_display_style = MidnightBlue, LightSteelBlue, 18px arial, 2, red" + "\n" \
                               + "distance_unit = km" + "\n" \
                               + "map_scale = 4.7")        # DISTANCE TOOL SCALE - CONUS
        else:
            hanis_config.write("\n" + "distance_display_style = MidnightBlue, LightSteelBlue, 18px arial, 2, red" + "\n" \
                               + "distance_unit = km" + "\n" \
                               + "map_scale = 1.79")        # DISTANCE TOOL SCALE - REGION

def filelist_write(region,f_name,model_time,meso_products,a_length):   # Writes HAniS filelist and downloads county overlay

    county_file = "http://www.spc.noaa.gov/exper/mesoanalysis/s" + str(region) + "/cnty/cnty.gif"   # Basemap URL
    cnty_dnld_nm = "cnty_r" + str(region) + ".gif"  # Basemap save as name
    download(county_file,cnty_dnld_nm)  # Download the Regional County Map of interest
    with open(f_name,"w") as hanis_filelist:
        for all_ in range(a_length):          # Creates the first part of each line of data for indv. hours
            hanis_filelist.write(cnty_dnld_nm + " \"" + model_time.strftime("%Y") + " " + model_time.strftime("%b") \
                        + " " + model_time.strftime("%d") + " - " + model_time.strftime("%H") + "Z\" " \
                        + "overlay = ")

            for each in range(len(meso_products)):  # Iterates through the product list on each line
                if meso_products[each] == "rgnlrad":    # HANDLES RADAR PRODUCTS
                    radar_file = "s" + str(region) + "/" + "rgnlrad/rad_" + model_time.strftime("%Y") + model_time.strftime("%m") \
                                + model_time.strftime("%d") + "_" + model_time.strftime("%H") + "00.gif"
                    hanis_filelist.write(radar_file + ",")  # Due to different filename convention, we write radar separately
                elif meso_products[each] == "warns":     # HANDLES WARNINGS PRODUCTS
                    #warn_file = "s" + str(region) + "/" + "warns/warns_" + modelrun.strftime("%Y") + modelrun.strftime("%m") \
                    #+ modelrun.strftime("%d") + "_" + modelrun.strftime("%H") + "00.gif"
                    warn_file = "s" + str(region) + "/" + "warns/warns_" + model_time.strftime("%Y") + model_time.strftime("%m") \
                                + model_time.strftime("%d") + "_" + model_time.strftime("%H") + "00.gif"
                    hanis_filelist.write(warn_file + ",")  # Due to different filename convention, we write warnings separately
                else:
                    hanis_filelist.write("s" + str(region) + "/" + meso_products[each] + "/" + meso_products[each] + "_" \
                                + model_time.strftime("%y") + model_time.strftime("%m") \
                                + model_time.strftime("%d") + model_time.strftime("%H") + ".gif,")
            hanis_filelist.write("\n")  # Line break between each hour
            model_time = model_time + datetime.timedelta(hours=1)   # Adds one hour to prep for next line/next hour of data

def html_write(rgn,model_time,config_filename,time_length):     # Writes/creates an HTML file for web-browser viewing
    model_time_start = model_time.strftime("%y") + model_time.strftime("%m") + model_time.strftime("%d") \
                       + model_time.strftime("%H") + "Z"
    model_time = model_time + datetime.timedelta(hours=time_length-1)
    model_time_finish = model_time.strftime("%y") + model_time.strftime("%m") + model_time.strftime("%d") \
                        + model_time.strftime("%H") + "Z" 
    html_filename = "s" + str(rgn) + "_" + model_time_start + "-" + model_time_finish + ".html"
    header = "<head>" + "\n" + "<title>" + html_filename + "</title>" + "\n" + "<script type=\"text/javascript\"" \
             + " src=\"./hanis_min.js\"></script>" + "\n" + "</head>\n"
    body = "<body onload =\"HAniS.setup(\'" + config_filename + "\',\'research\')\">" + "\n" + "<div id=\"research\" " \
           + "style=\"width:100%;\"></div>" + "\n" + "</body>"

    with open(html_filename,"w") as hanis_html:
        hanis_html.write("<html>" + "\n" + header + body + "\n" \
                         + "RMDaV Script was created by Kyle Gentry;\n" \
                         + "Animation made possible via HAniS module, Copyright© 2014-2017 by StormQuest Technologies and Tom Whittaker" + "</html>")

# MAIN
welcome_menu()   # Displays Welcome menu
sector = sector_menu()          # Asks User to Identify sector of interest
length = length_menu(sector)    # Asks User to determine length (in hours) of archive
initial_model = datetime.datetime.utcnow() - datetime.timedelta(hours=length-1)   # Finds initial Zero-Hour time
products, product_desc = product_menu(sector)      # Product menu
config_fn, filelist_fn = create_prep_files(sector,initial_model,length)    # Create blank files for HAniS Prep
make_dir(products,sector)   # Creates the directories if they do NOT exist already
sector_download(sector,products,initial_model,length)  # Retrieves the needed files

# Writes the needed files
config_write(sector,config_fn,filelist_fn,products,product_desc)   # Writes the HAniS config file
filelist_write(sector,filelist_fn,initial_model,products,length)     # Writes the HAniS filelist file (accessed by the config file)
html_write(sector,initial_model,config_fn,length)     # Writes the needed HTML file for viewing the loop
urllib.request.urlcleanup()     # Clears cache
