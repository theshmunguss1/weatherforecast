# Can't take credit for the following code. Its basic structure is found in numerous places online;
# It tricks your browser into thinking the local address of "localhost:9000" is the internet. HAniS
# requires this in some (maybe all) browsers to display properly. Try running the HTML file before 
# running this script to see if it works
import http.server
import socketserver

# RUNS A TEMPORARY WEB SERVER WITH PROGRAM DIRECTORY AS THE HOME DIRECTORY FOR THE SERVER
# AS LONG AS THE TERMINAL WINDOW STAYS OPEN, THE SERVER WILL REMAIN ACTIVE
PORT = 9000

Handler = http.server.SimpleHTTPRequestHandler

httpd = socketserver.TCPServer(("", PORT), Handler)

print("serving at port", PORT, "\nTHIS WINDOW MUST REMAIN OPEN FOR THE SERVER TO BE ACTIVE")
print("GOTO: http://localhost:9000/ AND SELECT THE HTML YOU NEED OPENED")
httpd.serve_forever()
