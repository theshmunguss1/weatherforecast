     Recent Mesoanalysis Downloader and Viewer (RMDaV)
-------------------------------------------------------------
   Released by Kyle Gentry, Mar 2018 :: ksgwxfan.github.io
-------------------------------------------------------------

*** Visit my project page for a more in-depth look at this script

INCLUDED (besides the readme file):
	- RMDaV.py (The main script); Run from Python and follow on-screen instructions
	- product_list.txt - DO NOT MODIFY! This contains the product prefixes and descriptions that the script needs
	- HTTPServer.py; Can't take credit for this creation. What it does is it tricks your PC
	into thinking your hard-drive (the program directory) is the internet; needed if your 
	browser doesn't display the animation. Just follow its instructions if you end up needing it.
	- HAniS v4.11 (hanis_min.js); keep the associated file(s) in the main directory where the script 
	will be stored.
PURPOSE: RMDaV downloads and, using the HAniS module, formulates an animated display with overlays of the 
	most recent Mesoanalysis data (updated by the Storm Prediction Center hourly; of the zero-hour 
	RAP data). I'd say it would be a handy companion tool for research. So if there is an event that
	occurs, one could archive necessary data for later research. The SPC outputs over 140 unique 
	products hourly, so there are plenty of variables out there to study.
WHY?: The SPC already archives CONUS data. This tool is primarily purposed for the regional mesoanalysis
	data. As of this release, regional data is only kept of the previous 80 hours or so. A regional 
	view can make figures/numbers easier to infer.
TERMS OF USE: Before you use this product, you must agree that the author of this program/script will not be held
	responsible for any adverse operation. The Python code may be redistributed as long as this readme
	file is included. That said, you must agree that the Python code WILL NOT be altered or represented
	as your own work. You are allowed to modify the config,filename,and product_list files, but doing so puts your
	animation display at risk of working improperly. 
	- HAniS (www.ssec.wisc.edu/hanis/) is included but has its own terms and conditions. See their site 
	for more details.
REQUIREMENTS:
	- Python (v3.5+)
	- HAniS module (included in the download); handles animation
	- Modern Web Browser; Javascript must be enabled (usually is)
INSTRUCTIONS: Before using, verify that all files in the download are extracted to the same directory and that 
	you have Python installed. During operation, more files and directories will be created. Following 
	creation, the files (HTML files) will be accessible without the primary Python file. A supplementary 
	Python program (can't take credit for it, found the basic script online; not exactly sure where) is 
	included to handle occasions that the animation does not display. Just run it follow the on-screen 
	instructions, and open the html file from the directory in that script

RMDaV created by Kyle Gentry

HAniS Copyright� 2014-2017 by StormQuest Technologies and Tom Whittaker