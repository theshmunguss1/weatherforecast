WCTFAVs FILES - created by Kyle Gentry
-----------------------------------------------
DISCLAIMER: The author is NOT responsible for any adverse operation
of the files downloaded and is not responsible for any supposed
damage caused thereby. Use at your own risk!

Intro: Thanks for downloading these files. I used Python to create 
them. Instead of including the code, I just included the files. They are
formatted for use inside of NOAA's Weather Climate Toolkit (WCT).

Purpose: The files created are grouped according to State, City, and 
close-in-proximity TDWR sites. The files directly reference the 
'sn.last,' or most-recent updated products on NWS's Telecommunication
Gateway (https://www.weather.gov/tg/radfiles). It is to simplify the use
of this freely-available and rapidly-updated data.

How to Use: If you haven't done so already, please unzip all of the files
within the archive into its own folder; Afterwards, access the appropriate
file within the favorites tab on the data button in NOAA WCT. Then Double-
click the desired product and it will be loaded into WCT.

*As a convenience, I included a 'mrms_products.WCTFAVS' files for easy
acess to the latest MRMS data.

Terms of Use: Feel free distribute or modify these files
