.WCTFAVS Files - Level-3 TDWR and WSR88D Radar Files
----------------------------------------------------

Creator:
--------
	- Kyle S. Gentry
	- https://ksgwxfan.github.io/

Release:
--------
	October 2021

Purpose:
--------
	- The files contained have been formatted for use in the program "NOAA Weather Climate Toolkit" (WCT).
	- They make accessing the most-recent level-3 radar data EXTREMELY simple.
	- A WCTFAV file for Multi-Radar Multi-Sensor (MRMS) Products has also been included.

Instructions:
-------------
	- Unzip all WCTFAV files to a directory of your choice.
	- Each WCTFAV File corresponds to a particular radar site.
		- TDWR Sites are all grouped in the same file, based on location (their State).
	- After opening WCT, in the 'Data Selector', click the 'Favorites' Tab.
	- Click 'Load List', and find the file you want to load.
	- A detailed Product Listing will appear. Double-click the one you want to load.

Notes:
------
	- The links to these radar files come from the NWS Telecommunications Gateway (https://tgftp.nws.noaa.gov/).
	- For each product, the most-recent ~200-300 files are available.
	- A special file, called 'sn.last' is always the most-recent file.
	- The links in these WCTFAV files point to that particular url.
	- I assembled these using Python.
	- If wanting to load a subsequent .WCTFAV file, it's recommended to clear the visible list (highlight all, and click remove) before doing so. Otherwise, the files you load are just placed after the last item that was previously loaded.

Disclaimer:
---------------
	- I'm not responsible for any adverse effects using these files (they're just tab-delimited text files)