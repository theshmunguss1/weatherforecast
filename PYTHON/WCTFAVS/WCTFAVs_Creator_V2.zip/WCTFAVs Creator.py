from time import sleep

input("       WELCOME TO WCTFAVs CREATOR :: by Kyle Gentry" + "\n" \
      + "                 astormyhaze.blogspot.com" + "\n" \
      + "----------------------------------------------------------------" + "\n" \
      + "WARNING! Before running this script, make sure you have " + "\n" \
      + "unzipped its files into their own folder. This script creates " + "\n" \
      + "well over 100 individual files and it will be cumbersome to use " + "\n" \
      + "if mingled within a directory not dedicated to it. If you " + "\n" \
      + "have NOT unzipped these files into their own directory, feel " + "\n" \
      + "free to do so now following closing this console. If you agree " + "\n" \
      + "to the terms in the readme file and if you're good to go, simply " + "\n" \
      + "press ENTER to run the script. Thank you!")

# Universal Variables
pre = "ftp://tgftp.nws.noaa.gov/SL.us008001/DF.of/DC.radar/DS."    # Link - Radar Directory
mid = "/SI."
end = "/sn.last"

# Product Lists and Descriptions
prod = []
desc = []
site = []
city = []

cycle = ["prod","desc","site","city"]

for index in cycle:     # For each array in the cycle array
    if index == "prod" or index == "desc":      # If product and descriptions are being defined
        with open("nwsL3.txt", "r") as nws:
            for each in nws.readlines():        # For every line ... "each" represents individual lines
                if index == "prod":
                    prod.append(each[:5])           # Extract the first 5 characters           
                else:
                    desc.append(each[6:].rstrip("\n"))      # Skips first 6 chars; takes off new-line at the end 
    else:                                       # If Cities and their Call-Signs are being defined
        with open("nwssites.txt", "r") as nws:
            for each in nws.readlines():        # For every line ... "each" represents individual lines
                if index == "site":
                    site.append(each[:4])           # Extracts the first 4 characters; the Call-Sign
                else:
                    city.append(each[5:].rstrip("\n"))       # Skips 5 chars; gets city name; deletes new-line

#f.write(pre + prod[j] + mid + site[i] + end + "\t" + desc[j] + "\n")

def wsrtdwr(site):  # Assist with taking care of TDWR sites near WSR88 sites
    site = site.upper()
    if site == "KAMX":  # MIAMI
        nl = [site,"TMIA","TFLL","TPBI"]
        fi = "FL - Miami - " + site + " and " + nl[1] + " and " + nl[2] + " and " + nl[3] + ".WCTFAVS"
        return nl,fi
    elif site == "KMLB":    # MELBOURNE
        nl = [site,"TMCO"]
        fi = "FL - Melbourne - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KTBW":    # TAMPA
        nl = [site,"TTPA"]
        fi = "FL - Tampa Bay - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KFFC":    # ATLANTA
        nl = [site,"TATL"]
        fi = "GA - Atlanta - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KGSP":    # GREENVILLE SPARTANBURG SC
        nl = [site,"TCLT"]
        fi = "SC - Greenville-Spartanburg - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KRAX":    # RALEIGH
        nl = [site,"TRDU"]
        fi = "NC - Raleigh - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KLWX":    # STERLING VA
        nl = [site,"TIAD","TDCA","IADW","TBWI"]
        fi = "VA - Sterling - " + site + " and " + nl[1] + " and " + nl[2] + " and " \
             + nl[3] + " and " + nl[4] +".WCTFAVS"
        return nl,fi
    elif site == "KDIX":    # MT HOLLY NJ
        nl = [site,"TPHL","TEWR","TJFK"]
        fi = "NJ - Mt Holly - " + site + " and " + nl[1] + " and " + nl[2] + " and " + nl[3] + ".WCTFAVS"
        return nl,fi
    elif site == "KBOX":    # BOSTON, MA
        nl = [site,"TBOS"]
        fi = "MA - Boston - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KPBZ":    # PITTSBURGH, PA
        nl = [site,"TPIT"]
        fi = "PA - Pittsburgh - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KCLE":    # CLEVELAND
        nl = [site,"TLVE"]
        fi = "OH - Cleveland - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KILN":  # WILMINGTON OH
        nl = [site,"TCMH","TDAY","TCVG"]
        fi = "OH - Wilmington - " + site + " and " + nl[1] + " and " + nl[2] + " and " + nl[3] + ".WCTFAVS"
        return nl,fi
    elif site == "KDTX":    # DETROIT
        nl = [site,"TDTW"]
        fi = "MI - Detroit - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KLVX":    # LOUISVILLE
        nl = [site,"TSDF"]
        fi = "KY - Louisville - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KIND":    # INDIANAPOLIS
        nl = [site,"TIDS"]
        fi = "IN - Indianapolis - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KOHX":    # NASHVILLE
        nl = [site,"TBNA"]
        fi = "TN - Nashville - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KLIX":    # NEW ORLEANS
        nl = [site,"TMSY"]
        fi = "LA - New Orleans - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KNQA":    # MEMPHIS
        nl = [site,"TMEM"]
        fi = "TN - Memphis - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KLSX":    # ST LOUIS
        nl = [site,"TSTL"]
        fi = "MO - St Louis - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KLOT":    # CHICAGO
        nl = [site,"TORD","TMDW"]
        fi = "IL - Chicago - " + site + " and " + nl[1] + " and " + nl[2] + ".WCTFAVS"
        return nl,fi
    elif site == "KMKX":    # MILWAUKEE
        nl = [site,"TMKE"]
        fi = "WI - Milwaukee - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KMPX":    # MINNEAPOLIS
        nl = [site, "TMSP"]
        fi = "MN - Minneapolis - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KEAX":    # KANSAS CITY
        nl = [site,"TMCI"]
        fi = "MO - Kansas City - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KINX":    # TULSA
        nl = [site,"TTUL"]
        fi = "OK - Tulsa - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KHGX":    # HOUSTON
        nl = [site,"THOU","TIAH"]
        fi = "TX - Houston - " + site + " and " + nl[1] + " and " + nl[2] + ".WCTFAVS"
        return nl,fi
    elif site == "KFWS":    # DALLAS
        nl = [site,"TDAL","TDFW"]
        fi = "TX - Dallas-Fort Worth - " + site + " and " + nl[1] + " and " + nl[2] + ".WCTFAVS"
        return nl,fi
    elif site == "KCRI":    # NORMAN
        nl = [site,"TOKC"]
        fi = "OK - Norman - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KTLX":    # OKC
        nl = [site,"TOKC"]
        fi = "OK - Oklahoma City - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KICT":    # WITCHITA
        nl = [site,"TICH"]
        fi = "KS - Witchita - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KFTG":    # DENVER
        nl = [site,"TDEN"]
        fi = "CO - Denver - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "KMTX":    # OGDEN
        nl = [site,"TSLC"]
        fi = "UT - Ogden - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    elif site == "TJUA":    # Eastern Puerto Rico
        nl = [site,"TSJU"]
        fi = "PR - Puerto Rico - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi
    else:
        nl = [site,"TLAS"]
        fi = "NV - Las Vegas - " + site + " and " + nl[1] + ".WCTFAVS"
        return nl,fi

print("\nScript Running. Please Wait...")
for i in range(len(city)):

    if site[i][0] == "t" or site[i][0] == "i":   # IF 1st LETTER IS a T; TDWR SITES ARE TAKEN CARE OF COMBINED WITH NEARBY WSR88Ds
        if site[i] == "tjua":
            newlist, filename = wsrtdwr(site[i])    # function that defines temp list with wsr/tdwr site and list of names
            for ea in newlist:
                newlist[newlist.index(ea)] = ea.lower()     # converts each product to lowercase as it is needed
            with open(filename, "w") as f:
                for each in range(1,len(newlist)):
                    for every in range(0,8):
                        if every == 0:
                            f.write(pre + prod[every] + mid + newlist[each] + end + "\t" + newlist[each].upper() + desc[every] + "\n")
                        else:
                            f.write(pre + prod[every] + mid + newlist[each] + end + "\t" + desc[every] + "\n")
                for each in range(8,len(prod)):
                    f.write(pre + prod[each] + mid + site[i] + end + "\t" + desc[each] + "\n")
        else:
            continue
    elif site[i] == "kamx" or site[i] == "kmlb" or site[i] == "ktbw" or site[i] == "kffc" or site[i] == "kgsp" \
         or site[i] == "krax" or site[i] == "klwx" or site[i] == "kdix" or site[i] == "kbox" or site[i] == "kpbz" \
         or site[i] == "kcle" or site[i] == "kiln" or site[i] == "kdtx" or site[i] == "klvx" or site[i] == "kind" \
         or site[i] == "kohx" or site[i] == "klix" or site[i] == "knqa" or site[i] == "klsx" or site[i] == "klot" \
         or site[i] == "kmkx" or site[i] == "kmpx" or site[i] == "keax" or site[i] == "kinx" or site[i] == "khgx" \
         or site[i] == "kfws" or site[i] == "kcri" or site[i] == "ktlx" or site[i] == "kict" or site[i] == "kftg" \
         or site[i] == "kmtx" or site[i] == "kesx":
        newlist, filename = wsrtdwr(site[i])    # function that defines temp list with wsr/tdwr site and list of names
        for ea in newlist:
            newlist[newlist.index(ea)] = ea.lower()     # converts each product to lowercase as it is needed
        with open(filename, "w") as f:
            for each in range(1,len(newlist)):
                for every in range(0,8):
                    if every == 0:
                        f.write(pre + prod[every] + mid + newlist[each] + end + "\t" + newlist[each] + desc[every] + "\n")
                    else:
                        f.write(pre + prod[every] + mid + newlist[each] + end + "\t" + desc[every] + "\n")
            for each in range(8,len(prod)):
                f.write(pre + prod[each] + mid + site[i] + end + "\t" + desc[each] + "\n")
    else:
        filename = city[i] + ".WCTFAVS"
        with open(filename, "w") as f:
            for j in range(8,len(prod)):
                f.write(pre + prod[j] + mid + site[i] + end + "\t" + desc[j] + "\n")

input("\n\n\nSCRIPT COMPLETE! Please press ENTER to close. The files will be accessible " + "\n" \
      "within NOAA Weather Climate Toolkit by opening the file dedicated to the " + "\n" \
      "desired site(s) through the 'Favorites' tab upon the 'Data' Button")
