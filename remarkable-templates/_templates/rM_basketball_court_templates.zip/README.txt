************************************************
reMarkable Compatible Basketball Court Templates
************************************************
v1.0
by Kyle Gentry

Purpose
-----------
- Use these as basketball shot-charts or designing plays.
- Portrait and Landscape variations are included in the file. Scaled variations
of NBA, NCAA, FIBA, and High-school courts are included.

Contents
-----------
- rM-basketball-templates.pdf
        - collection of 6.18"x8.24" PDF files of various basketball court
          diagrams.
- <<folder>> PNG_templates
        - collection of 1872x1404 PNG files of various basketball court
          diagrams. These should be suitable for use as templates for your
          device.

Use
-----------
- These files may be shared freely as long as no modification to the original files
has occurred.