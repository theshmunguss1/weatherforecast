import http.server
import socketserver

# RUNS A TEMPORARY WEB SERVER WITH PROGRAM DIRECTORY AS THE HOME DIRECTORY FOR THE SERVER
# AS LONG AS THE TERMINAL WINDOW STAYS OPEN, THE SERVER WILL REMAIN ACTIVE
PORT = 8001

Handler = http.server.SimpleHTTPRequestHandler

httpd = socketserver.TCPServer(("", PORT), Handler)

print("serving at port", PORT, "\nTHIS WINDOW MUST REMAIN OPEN FOR THE SERVER TO BE ACTIVE")
print("GOTO: http://localhost:8000/testing.html TO VIEW YOUR REQUESTED DATA")
httpd.serve_forever()
